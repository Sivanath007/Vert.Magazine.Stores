﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using System.Linq;
using System.Text;
/// <summary>
/// To identify all subscribers that are subscribed to at least one magazine in eachcategory.
/// </summary>
namespace Vertmarkets
{
    /// <summary>
    /// Get Token
    /// </summary>
    class Token
    {
        public string token { get; set; }
    }

    /// <summary>
    /// Get Categories
    /// </summary>
    class Category
    {
        public List<string> data  { get; set; }
    }

    /// <summary>
    /// Get Magazine based on Category
    /// </summary>
    class Magazine
    {
        public int id { get; set; }
        public string name { get; set; }
        public string category { get; set; }
    }

    /// <summary>
    /// Get the Subscribers
    /// </summary>
    class Subscribers
    {
        public string id { get; set; }
        public List<int> magazineIds { get; set; }
    }

    /// <summary>
    /// Final Result
    /// </summary>
    class Result
    {
        public List<string> subscribers { get; set; }
    }
    class Program
    {
        private readonly static string baseURL = "http://magazinestore.azurewebsites.net/";
        private readonly static string tokenURL = $"{baseURL}/api/token";
        private readonly static string categoriesURL = $"{baseURL}api/categories/";
        private readonly static string magazinesURL = $"{baseURL}/api/magazines/";
        private readonly static string magazinessubscribersURL = $"{baseURL}/api/subscribers/";
        private readonly static string postURL = $"{baseURL}/api/answer/";
        /// <summary>
        /// Vertmarkets to identify all subscribers that are subscribed to at least one magazine in each category.
        /// </summary>
        public static async void VertmarketsAsync()
        {
            try
            {
                Token token = await GetResult<Token>(tokenURL, "token").ConfigureAwait(false);
                Category categories = await GetResult<Category>($"{categoriesURL}{token.token}", "category").ConfigureAwait(false);
                List<Magazine> lstmagazines  = new List<Magazine>();
                Parallel.ForEach(categories.data, c =>
                {
                    List<Magazine> magazines = GetResult<List<Magazine>>($"{magazinesURL}{token.token}/{c}", "magazines").Result;
                    lstmagazines.AddRange(magazines);

                });
                List<Subscribers> magazinessubscribers = await GetResult<List<Subscribers>>($"{magazinessubscribersURL}{token.token}", "magazinessubscribers").ConfigureAwait(false);
                Result lstUser = new Result();
                lstUser.subscribers = new List<string>();
                Parallel.ForEach(magazinessubscribers, o =>
                {
                    var categoryWisesubscribers  = lstmagazines.Where(x => o.magazineIds.Contains(x.id)).Select(x => x.category).Distinct().Count();
                    if (categoryWisesubscribers == categories.data.Count())
                    {
                        lstUser.subscribers.Add(o.id);
                    }
                });
                var stringContent = new StringContent(JsonConvert.SerializeObject(lstUser), Encoding.UTF8, "application/json");
                var result = await PostResult(stringContent, $"{postURL}{token.token}").ConfigureAwait(false);
                Console.WriteLine(result);
                Console.Read();
            }
            catch (Exception ex)
            {
            }
        }

        /// <summary>
        /// To get the JSON result
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        private static async Task<T> GetResult<T>(string url, string api) where T:new()
        {
            T resultJson = new T();
            try
            {
                using (var httpcl = new HttpClient())
                {
                    var response = httpcl.GetAsync(url).GetAwaiter().GetResult();
                    if (response.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadAsStringAsync();
                        var parsedJson = JObject.Parse(result);
                        switch (api)
                        {
                            case "token":
                                resultJson = JsonConvert.DeserializeObject<T>(result);
                                break;
                            case "category":
                                resultJson = JsonConvert.DeserializeObject<T>(result);
                                break;
                            case "magazines":
                                resultJson = JsonConvert.DeserializeObject<T>(JsonConvert.SerializeObject(parsedJson["data"].Children()));
                                break;
                            case "magazinessubscribers":
                                resultJson = JsonConvert.DeserializeObject<T>(JsonConvert.SerializeObject(parsedJson["data"].Children()));
                                break;

                        }
                    }
                }
               
            }
            catch (Exception ex)
            {

            }
            return resultJson;
        }

        /// <summary>
        /// Post method for subscribers
        /// </summary>
        /// <param name="input"></param>
        /// <param name="api"></param>
        /// <returns></returns>
        private static async Task<string> PostResult(HttpContent input, string api)
        {
            string resultJson = string.Empty;
            try
            {
                using (var httpcl = new HttpClient())
                {
                    var response = httpcl.PostAsync(api, input).GetAwaiter().GetResult();
                    if (response.IsSuccessStatusCode)
                    {
                        resultJson = await response.Content.ReadAsStringAsync();

                    }
                }
                return resultJson;
            }
            catch (Exception ex)
            {
                return resultJson;

            }
            
        }

        /// <summary>
        /// Main Method entry point.
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            VertmarketsAsync();
        }
    }
}

